// Generated using https://hipsum.co/

// I'm a longer comment! Now, with Hipster Lorem Ipsum:
//
// Lorem ipsum dolor amet man braid +1 palo santo, whatever retro taxidermy
// quinoa cred venmo church-key. Pok pok cray cornhole selvage irony keytar
// disrupt man braid, everyday carry intelligentsia pitchfork street art hell
// of. Schlitz air plant beard, fam authentic health goth hella fashion axe palo
// santo pok pok. Hell of post-ironic artisan put a bird on it shoreditch shabby
// chic. Bitters 3 wolf moon food truck adaptogen.
//
// Paleo fanny pack poutine, williamsburg health goth four dollar toast
// aesthetic. Tbh viral truffaut live-edge asymmetrical ramps chillwave ethical
// keytar fixie post-ironic vaporware air plant intelligentsia. Wayfarers
// flannel iceland, DIY meditation celiac green juice disrupt. Food truck paleo
// bicycle rights cold-pressed roof party normcore tumblr.

let thisIsHereToBreakUpTheComments = 5

(* This is the same thing, but in a different comment syntax. *)

(* Lorem ipsum dolor amet man braid +1 palo santo, whatever retro taxidermy
quinoa cred venmo church-key. Pok pok cray cornhole selvage irony keytar disrupt
man braid, everyday carry intelligentsia pitchfork street art hell of. Schlitz
air plant beard, fam authentic health goth hella fashion axe palo santo pok pok.
Hell of post-ironic artisan put a bird on it shoreditch shabby chic. Bitters 3
wolf moon food truck adaptogen.

Paleo fanny pack poutine, williamsburg health goth four dollar toast aesthetic.
Tbh viral truffaut live-edge asymmetrical ramps chillwave ethical keytar fixie
post-ironic vaporware air plant intelligentsia. Wayfarers flannel iceland, DIY
meditation celiac green juice disrupt. Food truck paleo bicycle rights
cold-pressed roof party normcore tumblr. *)

/// Yet again the same thing, but in a doc comment.
///
/// Lorem ipsum dolor amet man braid +1 palo santo, whatever retro taxidermy
/// quinoa cred venmo church-key. Pok pok cray cornhole selvage irony keytar
/// disrupt man braid, everyday carry intelligentsia pitchfork street art hell
/// of. Schlitz air plant beard, fam authentic health goth hella fashion axe
/// palo santo pok pok. Hell of post-ironic artisan put a bird on it shoreditch
/// shabby chic. Bitters 3 wolf moon food truck adaptogen.
///
/// Paleo fanny pack poutine, williamsburg health goth four dollar toast
/// aesthetic. Tbh viral truffaut live-edge asymmetrical ramps chillwave ethical
/// keytar fixie post-ironic vaporware air plant intelligentsia. Wayfarers
/// flannel iceland, DIY meditation celiac green juice disrupt. Food truck paleo
/// bicycle rights cold-pressed roof party normcore tumblr.


let simple = "this is a very normal string"

let stringInString = "This contains another \"string\", so to speak."

let longer =
    """
    This is a triple-quoted string
    """

let evenLonger = """
This string is very long and had "normal extra quotes" and also
a small number of \"escaped quotes\", and also a gratuitous it's.
"""
