let x = 5
let y =
    [ 1; 2 ]
    |> List.fold (fun x y -> x + y)

let z = 5 +
        6
