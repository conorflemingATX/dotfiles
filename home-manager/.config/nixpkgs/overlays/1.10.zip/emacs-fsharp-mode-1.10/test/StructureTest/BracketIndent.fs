let formatOne = [ "this"
                  "that"
                  "the-other"

                              ]

let formatTwo = [
    "this"
    "that"

    ]

let formatThree =
    [ "this"
      "that"
      "the-other"
      "hi"

      ]
